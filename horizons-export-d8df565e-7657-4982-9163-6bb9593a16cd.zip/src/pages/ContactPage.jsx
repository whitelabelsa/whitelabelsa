
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { db } from '@/lib/db';

const ContactPage = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
       const { error } = await db.contact_messages.create(formData);
       if (error) throw error;
       toast({
        title: "تم الإرسال بنجاح",
        description: "شكراً لتواصلك معنا، سنرد عليك في أقرب وقت.",
        className: "bg-teal-primary text-white"
       });
       setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
    } catch (err) {
      toast({
        title: "خطأ",
        description: "حدث خطأ أثناء الإرسال، حاول مرة أخرى.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white min-h-screen py-12">
      <div className="container mx-auto px-4">
        {/* Banner Image */}
        <div className="w-full h-64 rounded-2xl overflow-hidden mb-12 shadow-lg relative">
            <img src="https://images.unsplash.com/photo-1630836260064-00718b9f3c06" alt="Contact Us" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-teal-primary/60 flex items-center justify-center">
                <h1 className="text-4xl font-bold text-white">تواصل معنا</h1>
            </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Info */}
          <div className="space-y-8">
            <div>
              <h2 className="text-3xl font-bold text-teal-primary mb-4">نحن هنا لمساعدتك</h2>
              <p className="text-gray-600 text-lg">نحن هنا للإجابة على استفساراتك ومساعدتك في بدء رحلة نجاحك.</p>
            </div>
            
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-teal-primary rounded-lg flex items-center justify-center text-white">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-lg mb-1 text-teal-primary">المقر الرئيسي</h3>
                  <p className="text-gray-600">الرياض، المملكة العربية السعودية</p>
                  <p className="text-gray-600">طريق الملك فهد، برج العليا</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-teal-primary rounded-lg flex items-center justify-center text-white">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-lg mb-1 text-teal-primary">اتصل بنا</h3>
                  <p className="text-gray-600">+966 50 000 0000</p>
                  <p className="text-gray-600">+20 10 0000 0000</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-teal-primary rounded-lg flex items-center justify-center text-white">
                  <Mail className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-lg mb-1 text-teal-primary">البريد الإلكتروني</h3>
                  <p className="text-gray-600">info@whitelabel.sa</p>
                  <p className="text-gray-600">support@whitelabel.sa</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-teal-primary rounded-lg flex items-center justify-center text-white">
                  <Clock className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-lg mb-1 text-teal-primary">ساعات العمل</h3>
                  <p className="text-gray-600">الأحد - الخميس: 9:00 ص - 5:00 م</p>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-beige-light p-8 rounded-2xl border border-gray-100 shadow-md">
            <h2 className="text-2xl font-bold mb-6 text-teal-primary">أرسل لنا رسالة</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1 text-teal-primary">الاسم</label>
                  <Input 
                    required 
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder="الاسم الكامل"
                    className="bg-white border-gray-200 focus:border-teal-primary"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1 text-teal-primary">رقم الهاتف</label>
                  <Input 
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    placeholder="+966..." 
                    className="bg-white border-gray-200 focus:border-teal-primary"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1 text-teal-primary">البريد الإلكتروني</label>
                <Input 
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  placeholder="name@example.com" 
                  className="bg-white border-gray-200 focus:border-teal-primary"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1 text-teal-primary">الموضوع</label>
                <Input 
                  required
                  value={formData.subject}
                  onChange={(e) => setFormData({...formData, subject: e.target.value})}
                  placeholder="موضوع الرسالة" 
                  className="bg-white border-gray-200 focus:border-teal-primary"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1 text-teal-primary">الرسالة</label>
                <textarea 
                  required
                  className="flex min-h-[120px] w-full rounded-md border border-gray-200 focus:border-teal-primary bg-white px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 text-slate-900"
                  value={formData.message}
                  onChange={(e) => setFormData({...formData, message: e.target.value})}
                  placeholder="كيف يمكننا مساعدتك؟" 
                />
              </div>
              <Button 
                type="submit" 
                disabled={loading}
                className="w-full bg-gold-accent hover:bg-[#B5952F] text-teal-primary font-bold"
              >
                {loading ? 'جاري الإرسال...' : 'إرسال الرسالة'}
              </Button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;
