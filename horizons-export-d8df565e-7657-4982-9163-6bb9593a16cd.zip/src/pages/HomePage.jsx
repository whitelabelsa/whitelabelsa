import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { HeartHandshake as Handshake, TrendingUp, CheckCircle, Ship, Truck, Target, Eye, FileText, ClipboardList, Plane, Building2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { db } from '@/lib/db';
const HomePage = () => {
  const {
    toast
  } = useToast();
  const [formData, setFormData] = useState({
    companyName: '',
    country: '',
    businessField: '',
    phone: '',
    email: ''
  });
  const [contactData, setContactData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [loading, setLoading] = useState(false);
  const [contactLoading, setContactLoading] = useState(false);
  const handleRegister = async e => {
    e.preventDefault();
    setLoading(true);
    try {
      if (!formData.companyName || !formData.email || !formData.phone) {
        throw new Error('يرجى ملء جميع الحقول المطلوبة');
      }
      const {
        error
      } = await db.registrations.create(formData);
      if (error) throw error;
      toast({
        title: "تم التسجيل بنجاح",
        description: "شكراً لتسجيلك، سنتواصل معك قريباً.",
        variant: "default",
        className: "bg-teal-primary text-white"
      });
      setFormData({
        companyName: '',
        country: '',
        businessField: '',
        phone: '',
        email: ''
      });
    } catch (err) {
      toast({
        title: "خطأ",
        description: err.message || "حدث خطأ أثناء التسجيل",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };
  const handleContactSubmit = async e => {
    e.preventDefault();
    setContactLoading(true);
    try {
      // Simulate API call or use db if applicable
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast({
        title: "تم الإرسال بنجاح",
        description: "شكراً لتواصلك معنا، سنرد عليك قريباً.",
        variant: "default",
        className: "bg-teal-primary text-white"
      });
      setContactData({
        name: '',
        email: '',
        message: ''
      });
    } catch (err) {
      toast({
        title: "خطأ",
        description: "حدث خطأ أثناء الإرسال",
        variant: "destructive"
      });
    } finally {
      setContactLoading(false);
    }
  };
  return <div className="flex flex-col gap-0 bg-beige-light font-cairo" dir="rtl">
      
      {/* 1. Hero Banner (البانر) */}
      <section className="relative h-[90vh] min-h-[600px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-cover bg-center z-0" style={{
        backgroundImage: 'url("https://images.unsplash.com/photo-1689942010216-dc412bb1e7a9")'
      }} />
        <div className="absolute inset-0 bg-gradient-to-r from-teal-primary/95 via-teal-primary/80 to-teal-secondary/60 z-10" />
        
        <div className="container relative z-20 text-white text-center px-4 max-w-4xl">
          <motion.div initial={{
          opacity: 0,
          y: -20
        }} animate={{
          opacity: 1,
          y: 0
        }} className="mb-4 inline-block bg-white/10 px-4 py-1 rounded-full text-gold-accent text-sm font-semibold backdrop-blur-sm border border-gold-accent/20">
            رؤية 2030 - نحو لوجستيات عالمية
          </motion.div>
          <motion.h1 initial={{
          opacity: 0,
          y: 30
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.8
        }} className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
            صدّر للعالم <br />
            <span className="text-gold-accent">بخطوات مدروسة</span>
          </motion.h1>
          <motion.p initial={{
          opacity: 0,
          y: 20
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          delay: 0.2,
          duration: 0.8
        }} className="text-xl md:text-2xl mb-10 text-gray-200 font-medium max-w-2xl mx-auto">اطلب أي منتج من مصر أو صنّعه حسب مواصفاتك الخاصة. نوفر لك حلولاً تجارية متكاملة بأمان تام وجودة مضمونة.

        </motion.p>
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          delay: 0.4,
          duration: 0.8
        }} className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-gold-accent text-teal-primary hover:bg-[#B5952F] text-lg px-8 py-6 h-auto font-bold border-0 min-w-[180px]">اطلب منتجك الان 
          </Button>
            <Button size="lg" variant="outline" className="bg-transparent border-2 border-white text-white hover:bg-white hover:text-teal-primary text-lg px-8 py-6 h-auto min-w-[180px]">
              تواصل معنا
            </Button>
          </motion.div>
        </div>
      </section>

      {/* 2. Statistics Section (سكشن الأرقام) */}
      <section className="py-12 -mt-20 relative z-30 container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 bg-teal-primary rounded-2xl shadow-xl p-8 border border-teal-secondary relative overflow-hidden">
          {[{
          number: "+500",
          label: "شركة مسجلة"
        }, {
          number: "+1,200",
          label: "فرصة تجارية"
        }, {
          number: "2",
          label: "أسواق إقليمية"
        }, {
          number: "24/7",
          label: "دعم مستمر"
        }].map((stat, idx) => <motion.div key={idx} initial={{
          opacity: 0,
          scale: 0.9
        }} whileInView={{
          opacity: 1,
          scale: 1
        }} viewport={{
          once: true
        }} className="text-center relative z-10 group hover:-translate-y-1 transition-transform duration-300">
              <h3 className="text-3xl md:text-4xl font-bold text-gold-accent mb-2">{stat.number}</h3>
              <p className="text-white font-medium">{stat.label}</p>
            </motion.div>)}
        </div>
      </section>

      {/* 3. About Us Section (من نحن) */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{
            opacity: 0,
            x: 50
          }} whileInView={{
            opacity: 1,
            x: 0
          }} viewport={{
            once: true
          }} className="space-y-6">
              <h4 className="text-gold-accent font-bold text-lg">من نحن</h4>
              <h2 className="text-3xl md:text-4xl font-bold text-teal-primary leading-tight">نربط بين مصر والسعودية بجسر من الثقة والجودة
            </h2>
              <p className="text-gray-600 leading-relaxed text-lg">وايت ليبل السعودية هي أول منصة متخصصة في التبادل التجاري بين مصر والمملكة العربية السعودية. نؤمن بأن التجارة يجب أن تكون سهلة وآمنة وموثوقة، لذلك أنشأنا منصة تجمع بين المصنعين المصريين المميزين والتجار السعوديين الباحثين عن منتجات عالية الجودة.

            </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
                <div className="flex gap-4 p-4 bg-beige-light rounded-lg border border-teal-secondary/10">
                  <div className="w-12 h-12 bg-teal-primary rounded-lg flex items-center justify-center shrink-0">
                    <Target className="w-6 h-6 text-gold-accent" />
                  </div>
                  <div>
                    <h3 className="font-bold text-teal-primary mb-2">رسالتنا</h3>
                    <p className="text-sm text-gray-600">تمكين الشركات من التوسع بثقة وأمان.</p>
                  </div>
                </div>
                
                <div className="flex gap-4 p-4 bg-beige-light rounded-lg border border-teal-secondary/10">
                  <div className="w-12 h-12 bg-teal-primary rounded-lg flex items-center justify-center shrink-0">
                    <Eye className="w-6 h-6 text-gold-accent" />
                  </div>
                  <div>
                    <h3 className="font-bold text-teal-primary mb-2">رؤيتنا</h3>
                    <p className="text-sm text-gray-600">ريادة التحول الرقمي في الخدمات اللوجستية.</p>
                  </div>
                </div>
              </div>
            </motion.div>
            
            <motion.div initial={{
            opacity: 0,
            x: -50
          }} whileInView={{
            opacity: 1,
            x: 0
          }} viewport={{
            once: true
          }} className="relative h-[400px] rounded-2xl overflow-hidden shadow-2xl">
              <img src="https://images.unsplash.com/photo-1531497684310-0f15276c39ab" alt="About Us" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-teal-primary/20 hover:bg-transparent transition-colors duration-500" />
            </motion.div>
          </div>
        </div>
      </section>

      {/* 4. What We Offer Section (ماذا نقدم) - 5 Services */}
      <section className="py-20 bg-beige-light">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h4 className="text-gold-accent font-bold mb-2">خدماتنا</h4>
            <h2 className="text-3xl md:text-4xl font-bold text-teal-primary mb-4">حلول متكاملة لنمو أعمالك</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">نقدم مجموعة شاملة من الخدمات المصممة خصيصاً لتلبية احتياجاتك التجارية واللوجستية</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 justify-center">
             {/* Service 1 */}
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} whileHover={{
            y: -5
          }} className="bg-white p-6 rounded-xl shadow-md border border-gray-100 text-center flex flex-col items-center">
              <div className="w-16 h-16 bg-teal-primary rounded-xl flex items-center justify-center mb-4 shadow-md text-white">
                <Ship className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-teal-primary">الاستيراد والتصدير</h3>
              <p className="text-gray-600 mb-4 text-sm">حلول شاملة لإدارة عمليات الاستيراد والتصدير بكفاءة عالية، من المصنع إلى المستودع.</p>
              <Button variant="link" className="text-teal-primary font-bold mt-auto hover:text-gold-accent p-0">
                اطلب الخدمة &larr;
              </Button>
            </motion.div>

            {/* Service 2 */}
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            delay: 0.1
          }} whileHover={{
            y: -5
          }} className="bg-white p-6 rounded-xl shadow-md border border-gray-100 text-center flex flex-col items-center">
              <div className="w-16 h-16 bg-teal-primary rounded-xl flex items-center justify-center mb-4 shadow-md text-white">
                <Truck className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-teal-primary">الشحن البري</h3>
              <p className="text-gray-600 mb-4 text-sm">أسطول حديث من الشاحنات المجهزة لنقل بضائعك بأمان وسرعة عبر الحدود.</p>
              <Button variant="link" className="text-teal-primary font-bold mt-auto hover:text-gold-accent p-0">
                اطلب الخدمة &larr;
              </Button>
            </motion.div>

            {/* Service 3 */}
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            delay: 0.2
          }} whileHover={{
            y: -5
          }} className="bg-white p-6 rounded-xl shadow-md border border-gray-100 text-center flex flex-col items-center">
              <div className="w-16 h-16 bg-teal-primary rounded-xl flex items-center justify-center mb-4 shadow-md text-white">
                <Handshake className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-teal-primary">الوساطة التجارية</h3>
              <p className="text-gray-600 mb-4 text-sm">ربطك بأفضل الموردين والعملاء وتأمين صفقات ناجحة ومربحة للطرفين.</p>
              <Button variant="link" className="text-teal-primary font-bold mt-auto hover:text-gold-accent p-0">
                اطلب الخدمة &larr;
              </Button>
            </motion.div>

             {/* Service 4 */}
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            delay: 0.3
          }} whileHover={{
            y: -5
          }} className="bg-white p-6 rounded-xl shadow-md border border-gray-100 text-center flex flex-col items-center">
              <div className="w-16 h-16 bg-teal-primary rounded-xl flex items-center justify-center mb-4 shadow-md text-white">
                <TrendingUp className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-teal-primary">الاستشارات الاستثمارية</h3>
              <p className="text-gray-600 mb-4 text-sm">دراسات جدوى دقيقة وتحليلات سوقية تساعدك على اتخاذ القرارات الصائبة.</p>
              <Button variant="link" className="text-teal-primary font-bold mt-auto hover:text-gold-accent p-0">
                اطلب الخدمة &larr;
              </Button>
            </motion.div>

             {/* Service 5 */}
             <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            delay: 0.4
          }} whileHover={{
            y: -5
          }} className="bg-white p-6 rounded-xl shadow-md border border-gray-100 text-center flex flex-col items-center md:col-span-2 lg:col-span-1">
              <div className="w-16 h-16 bg-teal-primary rounded-xl flex items-center justify-center mb-4 shadow-md text-white">
                <Plane className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-teal-primary">الشحن الجوي</h3>
              <p className="text-gray-600 mb-4 text-sm">خدمات شحن جوي سريع للبضائع الحساسة والمستعجلة بأفضل الأسعار.</p>
              <Button variant="link" className="text-teal-primary font-bold mt-auto hover:text-gold-accent p-0">
                اطلب الخدمة &larr;
              </Button>
            </motion.div>

          </div>
        </div>
      </section>

      {/* 5. Process Section (البروسيس) - 4 Steps */}
      <section className="py-20 bg-white relative overflow-hidden">
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-16">
            <h4 className="text-gold-accent font-bold mb-2">كيف نعمل</h4>
            <h2 className="text-3xl md:text-4xl font-bold text-teal-primary mb-4">رحلة نجاحك تبدأ هنا</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 relative">
             {/* Connector Line (Desktop) */}
            <div className="hidden md:block absolute top-12 left-0 right-0 h-0.5 bg-gray-200 z-0 mx-16" />

            {[{
            icon: FileText,
            title: "1. التسجيل",
            desc: "أنشئ حسابك وسجل بيانات شركتك في دقائق."
          }, {
            icon: ClipboardList,
            title: "2. الاختيار",
            desc: "اختر الخدمة المناسبة لاحتياجاتك من قائمتنا."
          }, {
            icon: Handshake,
            title: "3. التعاقد",
            desc: "نوقع الاتفاقيات ونبدأ في تنفيذ الإجراءات."
          }, {
            icon: CheckCircle,
            title: "4. التنفيذ",
            desc: "تابع سير العمل حتى اكتمال المهمة بنجاح."
          }].map((step, idx) => <motion.div key={idx} initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            delay: idx * 0.2
          }} className="relative z-10 text-center group">
                <div className="w-24 h-24 bg-white border-4 border-teal-primary rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg group-hover:scale-110 transition-transform duration-300">
                  <step.icon className="w-10 h-10 text-teal-primary" />
                </div>
                <h3 className="text-xl font-bold mb-3 text-teal-primary">{step.title}</h3>
                <p className="text-gray-600 text-sm">{step.desc}</p>
              </motion.div>)}
          </div>
        </div>
      </section>

      {/* 6. Registration Form Section (سكشن فورم) */}
      <section className="py-20 bg-teal-primary relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-5xl mx-auto bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col md:flex-row">
            <div className="md:w-5/12 bg-gold-accent p-10 flex flex-col justify-center text-teal-primary relative overflow-hidden">
              <div className="absolute inset-0 bg-pattern opacity-10" /> {/* Abstract pattern placeholder */}
              <h3 className="text-3xl font-bold mb-6 relative z-10">انضم إلينا اليوم</h3>
              <p className="mb-8 opacity-90 font-medium text-lg relative z-10">سجل شركتك الآن واستفد من شبكة علاقات واسعة وفرص تجارية حصرية لا تعوض.</p>
              <ul className="space-y-4 text-base font-medium relative z-10">
                <li className="flex items-center gap-3"><CheckCircle className="w-6 h-6" /> وصول فوري للفرص الاستثمارية</li>
                <li className="flex items-center gap-3"><CheckCircle className="w-6 h-6" /> شبكة شركاء موثوقين</li>
                <li className="flex items-center gap-3"><CheckCircle className="w-6 h-6" /> استشارات ودعم فني متواصل</li>
              </ul>
            </div>
            
            <div className="md:w-7/12 p-10 bg-white">
              <div className="mb-6">
                <h3 className="text-2xl font-bold text-teal-primary">تسجيل شركة جديدة</h3>
                <p className="text-gray-500 text-sm mt-1">أكمل البيانات التالية لإنشاء حساب شركتك</p>
              </div>
              <form onSubmit={handleRegister} className="space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-sm font-bold mb-2 text-teal-primary">اسم الشركة</label>
                    <Input required value={formData.companyName} onChange={e => setFormData({
                    ...formData,
                    companyName: e.target.value
                  })} placeholder="أدخل اسم الشركة" className="h-11 border-gray-300 focus:border-teal-primary bg-gray-50" />
                  </div>
                  <div>
                    <label className="block text-sm font-bold mb-2 text-teal-primary">الدولة</label>
                    <select className="w-full h-11 rounded-md border border-gray-300 focus:border-teal-primary bg-gray-50 px-3 py-2 text-sm text-slate-900 outline-none" value={formData.country} onChange={e => setFormData({
                    ...formData,
                    country: e.target.value
                  })} required>
                      <option value="">اختر الدولة</option>
                      <option value="saudi">المملكة العربية السعودية</option>
                      <option value="egypt">جمهورية مصر العربية</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-bold mb-2 text-teal-primary">مجال النشاط</label>
                  <select className="w-full h-11 rounded-md border border-gray-300 focus:border-teal-primary bg-gray-50 px-3 py-2 text-sm text-slate-900 outline-none" value={formData.businessField} onChange={e => setFormData({
                  ...formData,
                  businessField: e.target.value
                })} required>
                    <option value="">اختر المجال</option>
                    <option value="agriculture">الزراعة</option>
                    <option value="industrial">الصناعة</option>
                    <option value="logistics">الخدمات اللوجستية</option>
                    <option value="trade">التجارة العامة</option>
                    <option value="other">أخرى</option>
                  </select>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-sm font-bold mb-2 text-teal-primary">رقم الهاتف</label>
                    <Input type="tel" required value={formData.phone} onChange={e => setFormData({
                    ...formData,
                    phone: e.target.value
                  })} placeholder="+966..." className="h-11 border-gray-300 focus:border-teal-primary bg-gray-50" />
                  </div>
                  <div>
                    <label className="block text-sm font-bold mb-2 text-teal-primary">البريد الإلكتروني</label>
                    <Input type="email" required value={formData.email} onChange={e => setFormData({
                    ...formData,
                    email: e.target.value
                  })} placeholder="email@company.com" className="h-11 border-gray-300 focus:border-teal-primary bg-gray-50" />
                  </div>
                </div>
                <Button type="submit" disabled={loading} className="w-full bg-teal-primary hover:bg-teal-secondary text-white mt-4 font-bold h-12 text-lg shadow-lg hover:shadow-xl transition-all">
                  {loading ? 'جاري التسجيل...' : 'تسجيل الشركة الآن'}
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* 7. Contact Us Section (تواصل معنا) */}
      <section className="py-20 bg-beige-light">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h4 className="text-gold-accent font-bold mb-2">تواصل معنا</h4>
            <h2 className="text-3xl md:text-4xl font-bold text-teal-primary mb-4">نحن هنا للإجابة على استفساراتك</h2>
          </div>

          <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8 bg-white p-8 rounded-2xl shadow-lg border border-gray-100">
            <div>
              <h3 className="text-2xl font-bold text-teal-primary mb-6">معلومات الاتصال</h3>
              <div className="space-y-6">
                 <div className="flex items-start gap-4">
                   <div className="w-10 h-10 bg-teal-primary/10 rounded-lg flex items-center justify-center text-teal-primary shrink-0">
                     <Building2 className="w-5 h-5" />
                   </div>
                   <div>
                     <h4 className="font-bold text-teal-primary">العنوان</h4>
                     <p className="text-gray-600 text-sm">طريق الملك فهد، برج العليا، الرياض</p>
                   </div>
                 </div>
                 
                 <div className="flex items-start gap-4">
                   <div className="w-10 h-10 bg-teal-primary/10 rounded-lg flex items-center justify-center text-teal-primary shrink-0">
                     <FileText className="w-5 h-5" /> {/* Phone icon replacement if needed, using generic for contact */}
                   </div>
                   <div>
                     <h4 className="font-bold text-teal-primary">البريد الإلكتروني</h4>
                     <p className="text-gray-600 text-sm">info@whitelabel.sa</p>
                   </div>
                 </div>

                 <div className="mt-8 pt-8 border-t border-gray-100">
                   <p className="text-gray-500 text-sm leading-relaxed">
                     فريق خدمة العملاء متاح للرد على استفساراتكم طوال أيام الأسبوع من الساعة 9 صباحاً وحتى 5 مساءً.
                   </p>
                 </div>
              </div>
            </div>

            <div>
              <form onSubmit={handleContactSubmit} className="space-y-4">
                <div>
                  <Input placeholder="الاسم الكامل" value={contactData.name} onChange={e => setContactData({
                  ...contactData,
                  name: e.target.value
                })} className="bg-gray-50 border-gray-200" required />
                </div>
                <div>
                  <Input type="email" placeholder="البريد الإلكتروني" value={contactData.email} onChange={e => setContactData({
                  ...contactData,
                  email: e.target.value
                })} className="bg-gray-50 border-gray-200" required />
                </div>
                <div>
                  <textarea placeholder="اكتب رسالتك هنا..." value={contactData.message} onChange={e => setContactData({
                  ...contactData,
                  message: e.target.value
                })} className="flex min-h-[120px] w-full rounded-md border border-gray-200 bg-gray-50 px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 text-slate-900" required />
                </div>
                <Button type="submit" disabled={contactLoading} className="w-full bg-gold-accent hover:bg-[#B5952F] text-teal-primary font-bold">
                  {contactLoading ? 'جاري الإرسال...' : 'إرسال الرسالة'}
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>

    </div>;
};
export default HomePage;