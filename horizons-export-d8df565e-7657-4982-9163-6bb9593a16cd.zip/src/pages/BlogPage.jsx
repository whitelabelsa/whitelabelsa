
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const BlogPage = () => {
  const posts = [
    {
      title: "فرص التجارة الواعدة بين السعودية ومصر 2024",
      excerpt: "استعراض لأهم القطاعات التي تشهد نمواً متسارعاً وفرصاً استثمارية جذابة في العام الجديد...",
      date: "15 يناير 2024",
      category: "اقتصاد",
      image: "https://images.unsplash.com/photo-1671190364105-350df407f834"
    },
    {
      title: "دليل المصدر المصري للسوق السعودي",
      excerpt: "كل ما تحتاج معرفته عن الاشتراطات والمواصفات السعودية لتصدير منتجاتك بنجاح...",
      date: "10 يناير 2024",
      category: "تصدير",
      image: "https://images.unsplash.com/photo-1561475699-d6dc71581653"
    },
    {
      title: "التسهيلات اللوجستية الجديدة للمستثمرين",
      excerpt: "تعرف على أحدث الاتفاقيات الموقعة لتسهيل حركة النقل والشحن بين البلدين...",
      date: "05 يناير 2024",
      category: "لوجستيات",
      image: "https://images.unsplash.com/photo-1618317502010-1a3a94ab9b75"
    },
    {
      title: "قصص نجاح شركات ناشئة توسعت إقليمياً",
      excerpt: "نستعرض تجارب ملهمة لشركات بدأت صغيرة ونجحت في غزو الأسواق المجاورة...",
      date: "28 ديسمبر 2023",
      category: "ريادة أعمال",
      image: "https://images.unsplash.com/photo-1531497684310-0f15276c39ab"
    }
  ];

  return (
    <div className="bg-white min-h-screen py-12">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-teal-primary mb-4">المدونة</h1>
          <p className="text-gray-600">أحدث المقالات والأخبار حول الاقتصاد والاستثمار والتجارة</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {posts.map((post, idx) => (
            <Card key={idx} className="hover:shadow-lg transition-shadow overflow-hidden group border-gray-200 bg-beige-light">
              <div 
                className="h-48 bg-gray-200 group-hover:scale-105 transition-transform duration-500 bg-cover bg-center"
                style={{ backgroundImage: `url(${post.image})` }}
              />
              <CardContent className="p-6">
                <div className="flex items-center justify-between text-xs text-gray-500 mb-3">
                  <span className="bg-teal-primary/10 text-teal-primary px-2 py-1 rounded font-medium">{post.category}</span>
                  <span>{post.date}</span>
                </div>
                <h3 className="font-bold text-lg mb-3 leading-tight text-teal-primary group-hover:text-teal-secondary transition-colors">{post.title}</h3>
                <p className="text-[#666666] text-sm mb-4 line-clamp-2">{post.excerpt}</p>
                <Button className="w-full bg-gold-accent hover:bg-[#B5952F] text-teal-primary font-bold">اقرأ المزيد</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BlogPage;
