
import React from 'react';
import { motion } from 'framer-motion';
import { Target, Eye, Award } from 'lucide-react';
import { Button } from '@/components/ui/button';

const AboutPage = () => {
  return (
    <div className="bg-beige-light">
      {/* Hero */}
      <div className="relative h-[400px] flex items-center justify-center">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1531497684310-0f15276c39ab")' }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-teal-primary/90 to-teal-secondary/80" />
        <div className="relative z-10 text-center text-white p-4">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl font-bold mb-4"
          >
            من نحن
          </motion.h1>
          <p className="text-xl max-w-2xl mx-auto text-gold-accent font-medium">شريكك الاستراتيجي للنمو والنجاح في الأسواق السعودية والمصرية</p>
        </div>
      </div>

      {/* Mission & Vision */}
      <section className="py-20 container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h2 className="text-3xl font-bold text-teal-primary">قصتنا</h2>
            <p className="text-gray-600 leading-relaxed">
              تأسست منصة "وايت ليبل" انطلاقاً من رؤية طموحة لتعزيز التبادل التجاري وتوطيد العلاقات الاقتصادية بين المملكة العربية السعودية وجمهورية مصر العربية. نحن ندرك حجم الفرص الكامنة في التكامل بين هذين الاقتصادين الكبيرين، ونسعى لتذليل العقبات التي تواجه المستثمرين ورواد الأعمال.
            </p>
            <p className="text-gray-600 leading-relaxed">
              فريقنا يجمع بين الخبرة العميقة في الأنظمة والقوانين التجارية في كلا البلدين، وشبكة علاقات واسعة، مما يمكننا من تقديم حلول عملية وفعالة لعملائنا.
            </p>
            <Button className="bg-gold-accent hover:bg-[#B5952F] text-teal-primary font-bold mt-4">
                تواصل معنا
            </Button>
          </div>
          <div className="grid grid-cols-1 gap-6">
            <div className="bg-white p-6 rounded-xl border-r-4 border-teal-primary shadow-sm">
              <div className="flex items-center gap-3 mb-3">
                <Target className="w-6 h-6 text-gold-accent" />
                <h3 className="font-bold text-xl text-teal-primary">رسالتنا</h3>
              </div>
              <p className="text-gray-600">تمكين الشركات من التوسع والنمو عبر توفير بيئة أعمال متكاملة وخدمات استشارية ولوجستية رفيعة المستوى.</p>
            </div>
            <div className="bg-white p-6 rounded-xl border-r-4 border-gold-accent shadow-sm">
              <div className="flex items-center gap-3 mb-3">
                <Eye className="w-6 h-6 text-teal-primary" />
                <h3 className="font-bold text-xl text-teal-primary">رؤيتنا</h3>
              </div>
              <p className="text-gray-600">أن نكون المنصة الأولى والمرجع الموثوق للأعمال والاستثمار بين السعودية ومصر بحلول عام 2030.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-12 text-teal-primary">قيمنا الجوهرية</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { title: "النزاهة", icon: Award },
              { title: "الاحترافية", icon: Target },
              { title: "الابتكار", icon: Eye },
              { title: "الشراكة", icon: Target }
            ].map((val, idx) => (
              <div key={idx} className="bg-beige-light p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow border border-gray-100">
                <div className="w-16 h-16 bg-teal-primary rounded-full flex items-center justify-center mx-auto mb-4">
                    <val.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-bold text-lg text-teal-primary">{val.title}</h3>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Partnership Image Section */}
      <section className="py-12 bg-beige-light">
          <div className="container mx-auto px-4">
              <div className="rounded-2xl overflow-hidden shadow-xl h-[400px] relative">
                  <img src="https://images.unsplash.com/photo-1686771416282-3888ddaf249b" alt="Strategic Partnership" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-teal-primary/40 flex items-center justify-center">
                      <h2 className="text-4xl font-bold text-white drop-shadow-lg">نبني جسوراً من الثقة</h2>
                  </div>
              </div>
          </div>
      </section>
    </div>
  );
};

export default AboutPage;
