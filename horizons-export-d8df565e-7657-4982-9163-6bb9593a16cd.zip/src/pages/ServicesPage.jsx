
import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Check } from 'lucide-react';

const ServicesPage = () => {
  const services = [
    {
      title: "الربط بين الموردين والمشترين",
      desc: "نستخدم تقنيات ذكية وشبكة علاقات واسعة لربطك بأفضل الشركاء المحتملين الذين يتناسبون مع متطلبات عملك وميزانيتك.",
      features: ["قاعدة بيانات ضخمة", "تحقق من الموثوقية", "مفاوضات أولية"],
      image: "https://images.unsplash.com/photo-1561475699-d6dc71581653"
    },
    {
      title: "الوساطة التجارية",
      desc: "نقوم بدور الوسيط الأمين في إتمام الصفقات التجارية، ونشرف على العقود والاتفاقيات لضمان حقوق جميع الأطراف.",
      features: ["عقود قانونية", "ضمان مالي", "إشراف على التنفيذ"],
      image: "https://images.unsplash.com/photo-1686771416282-3888ddaf249b" 
    },
    {
      title: "تسهيل الاستيراد والتصدير",
      desc: "نقدم حلولاً شاملة للتخليص الجمركي والشحن والنقل، مع ضمان الالتزام بكافة المعايير والاشتراطات في كلا البلدين.",
      features: ["تخليص جمركي", "شحن بري وبحري", "شهادات مطابقة"],
      image: "https://images.unsplash.com/photo-1618317502010-1a3a94ab9b75"
    },
    {
      title: "دعم الشراكات الاستراتيجية",
      desc: "نساعد الشركات الكبرى في بناء تحالفات استراتيجية طويلة الأمد ومشاريع مشتركة تعزز من قدراتها التنافسية.",
      features: ["دراسات اندماج", "مشاريع مشتركة", "تمثيل تجاري"],
      image: "https://images.unsplash.com/photo-1531497684310-0f15276c39ab"
    }
  ];

  return (
    <div className="bg-beige-light min-h-screen py-12">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-teal-primary mb-4">خدماتنا المتكاملة</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">نقدم مجموعة واسعة من الخدمات المصممة خصيصاً لتلبية احتياجات المستثمرين ورجال الأعمال في السعودية ومصر.</p>
        </div>

        <div className="grid grid-cols-1 gap-12">
          {services.map((service, idx) => (
            <div key={idx} className="bg-white rounded-2xl p-8 shadow-sm flex flex-col md:flex-row gap-8 items-center border border-gray-100 hover:shadow-md transition-shadow">
              <div className="md:w-1/2 order-2 md:order-1">
                <div className="w-12 h-12 bg-teal-primary text-white rounded-lg flex items-center justify-center font-bold text-xl mb-6">
                  {idx + 1}
                </div>
                <h2 className="text-2xl font-bold mb-4 text-teal-primary">{service.title}</h2>
                <p className="text-gray-600 mb-6 leading-relaxed">{service.desc}</p>
                <ul className="space-y-3 mb-8">
                  {service.features.map((feature, fIdx) => (
                    <li key={fIdx} className="flex items-center gap-3 text-sm text-gray-700">
                      <div className="w-5 h-5 rounded-full bg-gold-accent/20 flex items-center justify-center text-gold-accent">
                        <Check className="w-3 h-3" />
                      </div>
                      {feature}
                    </li>
                  ))}
                </ul>
                <div className="flex gap-4">
                    <Button className="bg-gold-accent hover:bg-[#B5952F] text-teal-primary font-bold">
                    اطلب الخدمة <ArrowLeft className="w-4 h-4 mr-2" />
                    </Button>
                    <Button variant="outline" className="border-teal-primary text-teal-primary hover:bg-teal-primary hover:text-white">
                        تفاصيل أكثر
                    </Button>
                </div>
              </div>
              <div 
                className="md:w-1/2 rounded-xl h-64 w-full bg-cover bg-center shadow-md order-1 md:order-2"
                style={{ backgroundImage: `url(${service.image})` }}
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ServicesPage;
